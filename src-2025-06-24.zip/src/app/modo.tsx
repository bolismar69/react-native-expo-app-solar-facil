import { Redirect } from "expo-router";

// /src/app/faq.tsx
export default function AppFaqScreen() {
  return (
    <Redirect href="/" />
  )
}
