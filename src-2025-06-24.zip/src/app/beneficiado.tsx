// /src/app/beneficiado.tsx
import React from "react";
import BeneficiadoScreen from "@/screens/beneficiado/BeneficiadoScreen";

export default function AppBeneficiadoScreen() {
  console.log("AppBeneficiadoScreen");
  return (
    <BeneficiadoScreen />
  );
}
