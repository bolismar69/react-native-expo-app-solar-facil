// /src/app/email.tsx
import React from "react";
import { Text, View } from "react-native";

export default function AppEmailScreen() {
  return (
    <View>
      <Text>AppEmailScreen</Text>
    </View>
  );
}
