// /src/app/sobre.tsx
import React from "react";
import { Text, View } from "react-native";

export default function AppWhatsappScreen() {
  return (
    <View>
      <Text>AppWhatsappScreen</Text>
    </View>
  );
}
