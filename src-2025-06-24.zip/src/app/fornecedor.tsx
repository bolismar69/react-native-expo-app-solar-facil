// /src/app/fornecedor.tsx
import React from "react";
import FornecedorScreen from "@/screens/fornecedor/FornecedorScreen";

export default function AppFornecedorScreen() {
  console.log("AppFornecedorScreen");
  return (
    <FornecedorScreen />
  );
}
