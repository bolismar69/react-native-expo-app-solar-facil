export type ConcessionariaType = {
  id: number;
  name: string;
  status: "active" | "inactive";
};
