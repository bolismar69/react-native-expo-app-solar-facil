// /src/app/fornecedor.tsx
import React from "react";
import FornecedorCadastroScreen from "@/screens/fornecedor/FornecedorCadastroScreen";

export default function AppFornecedorCadastroScreen() {
  console.log("AppFornecedorCadastroScreen");
  return (
    <FornecedorCadastroScreen />
  );
}
