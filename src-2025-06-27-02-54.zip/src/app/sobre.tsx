// /src/app/sobre.tsx
import SobreScreen from "@/screens/general/SobreScreen";
import React from "react";
// import { Text, View } from "react-native";

export default function AppSobreScreen() {
  return (
    // <View>
    //   <Text>AppSobreScreen</Text>
    // </View>
    <SobreScreen />
  );
}
