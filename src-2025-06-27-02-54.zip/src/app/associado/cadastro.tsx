// /src/app/associado/cadastro.tsx
import AssociadoCadastroScreen from "@/screens/associado/AssociadoCadastroScreen";

export default AssociadoCadastroScreen;
