// /src/app/associado/_layout.tsx
import { Stack } from "expo-router";

export default function AssociadoLayout() {
  return (
    <Stack screenOptions={{ headerShown: true }}>
      {/* Stack router controlando as rotas filho de /associado */}
    </Stack>
  );
}
