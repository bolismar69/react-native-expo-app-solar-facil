// /src/app/associado/cadastro.tsx
import AssociadoDadosCadastraisScreen from "@/screens/associado/AssociadoDadosCadastraisScreen";

export default AssociadoDadosCadastraisScreen;
