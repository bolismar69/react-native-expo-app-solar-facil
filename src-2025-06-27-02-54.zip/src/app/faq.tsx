// /src/app/faq.tsx
// import FAQScreen from "@/screens/general/FAQScreen";
import FAQScreen from "@/screens/general/FAQScreen";
import React from "react";

export default function AppFaqScreen() {
  return (
    console.log("AppFaqScreen"),
    <FAQScreen />
  );
}
