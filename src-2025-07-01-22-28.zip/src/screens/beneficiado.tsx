// /src/app/beneficiado.tsx
import React from "react";
import BeneficiadoCadastroScreen from "@/screens/beneficiado/BeneficiadoCadastroScreen";

export default function AppBeneficiadoCadastroScreen() {
  console.log("BeneficiadoCadastroScreen");
  return (
    <BeneficiadoCadastroScreen />
  );
}
