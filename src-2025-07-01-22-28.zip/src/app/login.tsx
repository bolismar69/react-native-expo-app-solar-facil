// src/app/associado/index.tsx
import AssociadoLoginScreen from "@/screens/associado/AssociadoLoginScreen";

export default AssociadoLoginScreen;
