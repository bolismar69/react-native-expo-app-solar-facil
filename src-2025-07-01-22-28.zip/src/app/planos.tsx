// /src/app/planos.tsx
import PlanosScreen from "@/screens/general/PlanosScreen";
import React from "react";

export default function AppPlanosScreen() {
  console.log("AppPlanosScreen");
  return (
    // <View>
    //   <Text>AppSobreScreen</Text>
    // </View>
    <PlanosScreen />
  );
}
