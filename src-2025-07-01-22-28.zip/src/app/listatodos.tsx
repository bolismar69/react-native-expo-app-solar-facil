// /src/app/sobre.tsx
import React from "react";
import AssociadoListaTodosScreen from "@/screens/associado/AssociadoListaTodosScreen";

export default function AppListaTodosScreen() {
  console.log("AppListaTodosScreen");
  return (
    <AssociadoListaTodosScreen />
  );
}
