// /src/app/sobre.tsx
import SaibaMaisScreen from "@/screens/general/SaibaMaisScreen";
import React from "react";
// import { Text, View } from "react-native";

export default function AppSobreScreen() {
  return (
    // <View>
    //   <Text>AppSobreScreen</Text>
    // </View>
    <SaibaMaisScreen />
  );
}
